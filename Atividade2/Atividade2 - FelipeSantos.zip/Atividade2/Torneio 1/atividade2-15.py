x, y = input().split(" ")
x = int(x)
y = int(y)

if x >= 0 and x <= 432:
    if y >= 0 and y <= 468:
        print('dentro')
    else:
        print('fora')
else:
    print('fora')