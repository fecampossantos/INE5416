# -*- coding: utf-8 -*-

R = float(input().strip())

pi = 3.14159
volume = (4/3.0) * pi * R**3

print('VOLUME = ' + "{:.3f}".format(volume))