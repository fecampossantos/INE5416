a = input()
a = int(a)

b = input()
b = int(b)

print(a-b)